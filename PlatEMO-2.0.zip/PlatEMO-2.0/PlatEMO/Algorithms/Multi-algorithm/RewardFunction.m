function Reward = Reward(PopObj,PF,action,Scorelist)
state = PopObj;
Score = IGD(PopObj,PF)




    


end

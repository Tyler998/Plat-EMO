function NewParticles = PIO(Global,Parent,Gbest)
% <operator> <real>
% Particle swarm optimization
% R --- 0.6 --- The inertia weight in PIO

%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group
    R = Global.ParameterSet(0.6);
    ParentDec = Parent.decs;
    GbestDec    = Gbest.decs;
    [N,D]       = size(ParentDec);
    ParentSpeed = Parent.adds(zeros(N,D));
   
 
    %% PIO
    c = repmat(rand(N,1),1,D);
    %前80次用地磁算子,后20次用地标算子。
    if Global.gen<80
        NewSpeed = ParentSpeed*exp(-R*Global.gen) + c.*(GbestDec-ParentDec);
    else
        Archive = Gbest(NDSort(Gbest.objs,1)==1);
        sum=0
        for i = 1:length(Archive)    
            %[0.2,0.2,0.4,0.2]为每个优化目标的权重
            sum = sum+ Archive(i).obj*[0.2,0.2,0.4,0.2]'
        end
        mid= sum/length(Archive)
        temp=zeros(length(Archive)/2,D);
        %将Archive中的一半的粒子的决策变量放到temp矩阵，方便计算均值。
        for i =1:length(Archive)
            if sum+ Archive(i).obj*[0.2,0.2,0.4,0.2]'< mid
                temp(i,:)=Archive(i).dec;
            end
        end  
        CenterDec = mean(temp);
        NewSpeed = ParentSpeed+rand*(CenterDec-ParentSpeed);
    end
        NewDec   = ParentDec + NewSpeed;
        NewParticles = INDIVIDUAL(NewDec,NewSpeed);
end
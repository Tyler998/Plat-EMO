%***************initialization******************* 
global bound;
T1=90;     %Global search algebra 地磁导航次数
T2=15;     %Local search algebra 地标导航次数
pigeonnum=30;    %number  种群数
D=1;      % dimensionality 解维数（平面为二维）
R=0.3;     %parameters of magnetic field  地磁因数
bound=[0,20];    %hunting zone 解空间
%**************initialization of the individual pigeon************ 生成初始解
for i=1:pigeonnum 
    for j=1:D 
        x(i,j)=bound(1)+rand*(bound(2)-bound(1)); 
        v(i,j)=rand; 
    end 
end 
%**************calculate the fitn,,,,Mess of pigeon*********** 计算适应度值
for i=1:pigeonnum 
    p(i)=f1(x(i,:),D); 
end 
%**************find the optimal pigeons 求最优解
g_best=x(1,:); 
for i=2:pigeonnum 
    if f1(g_best,D)<f1(x(i,:),D) 
        g_best=x(i,:); 
    end 
end 
%************  magnetic compass and solar operator******************** 地磁导航
for t=1:T1 %每次迭代
    for i=1:pigeonnum  %每个鸽子
        v(i,:)=v(i,:)*exp(-R*t)+rand*(g_best-x(i,:)); 
        x(i,:)=x(i,:)+v(i,:);%更新位置速度  
        for j=1:D%每个维度  
            if x(i,j)<bound(1)||x(i,j)>bound(2)   %检查解是否超出范围，超出则重新初始化
                x(i,j)=bound(1)+rand*(bound(2)-bound(1)); 
                v(i,j)=rand; 
            end 
        end 
        %新的种群中如果适应度大于以前的最优解，就更新
        if f1(g_best,D) < f1(x(i,:),D) %更新全局最优解
            g_best=x(i,:); 
        end 
    end 
    result(t)=f1(g_best,D); %记录本次迭代最优解
end 
%*************地标算子导航********************** 
for t=1:T2 
    for i=1:pigeonnum-1                            
        for j=i+1:pigeonnum 
            if f1(x(j,:),D)> f1(x(i,:),D)
                temp_pigeon=x(i,:); 
                x(i,:)=x(j,:); 
                x(j,:)=temp_pigeon; 
            end 
        end 
    end  %sort the pigeons 按适应度对粒子排序,从小到大排
    
    pigeonnum=ceil(pigeonnum/2);  %remove half of the pigeons according to the landmark 减半
    addpigeonnum=0;                        
    for i=1:pigeonnum 
        p(i)=f1(x(i,:),D); 
        addpigeonnum=addpigeonnum+x(i,:)*p(i); 
        pigeonnumc=sum(p(i));%calculate fitness and location of the pigeon after sorting 求和
    end 
    pigeoncenter=ceil(addpigeonnum/pigeonnum*pigeonnumc);%calculate central position 求中心
     x(i,:)=x(i,:)+rand*(pigeoncenter-x(i,:));%更新位置
    for i=1:pigeonnum                                %local searching        
        for j=1:D                                    %check whether beyond the searching space 
            if x(i,j)<bound(1)||x(i,j)>bound(2) 
                x(i,j)=bound(1)+rand*(bound(2)-bound(1)); 
                v(i,j)=rand; 
            end 
        end 
        if f1(g_best,D)   <     f1(x(i,:),D)                  %renewal global fitness 
            g_best=x(i,:); 
        end 
    end 
    result(t+T1)=f1(g_best,D); 
end 



figure                                               %graph 
for t=1:T1+T2-1 
    plot([t,t+1],[result(t),result(t+1)]); 
    hold on; 
end


%rastrigin函数：多峰，极小值分布呈规律性 最优f=0，X(i)=0
function R = f1(x,in)
R=x .* sin(x) .* cos(2 * x) - 2 * x .* sin(3 * x);
end   
function F = Cal(P)
    %加载数据
    load re.txt
    load datasets.txt
    xSize = size(P,1);
    D = size(P,2);
    rel = re;
    data = datasets;
    f=1./(1+exp(-1.*rel))-0.5;
    cost=zeros(1,xSize);   %成本
    time=zeros(1,xSize);   %时间
    reliability=ones(1,xSize);%可靠性
    relat=zeros(1,xSize);  %关系
    for i=1:xSize
        for j=1:D 
            P(i,j) = round(P(i,j));
            cost(i) = cost(i)+data(P(i,j),1);  
            time(i) = time(i)+data(P(i,j),2);
            reliability(i) = reliability(i)*data(P(i,j),3); 
        end
        % time(i) = compute(P(i,:));
        relat(i)= relation(P,f,3,i);  
    end
    y = zeros(xSize, 4);
    y(:,1) = cost(:);
    y(:,2) = time(:);
    y(:,3) =- relat(:);
    y(:,4) = - reliability(:);
    F = y;
end
classdef CloudManufacture < PROBLEM
% <problem> <MOP in CloudManufacture>
% CloudManufacture for Evolutionary Multi-Objective Optimization
    methods
     %% Initialization
        function obj = CloudManufacture()
            if isempty(obj.Global.M)
                obj.Global.M = 4;
            end
            if isempty(obj.Global.D)
                obj.Global.D = 8;
            end
            temp = colon(1,fix(1000/obj.Global.D),1000);
            if length(temp)>obj.Global.D
                temp=temp(1:length(temp)-1);
            end
            
            obj.Global.lower = temp(1:length(temp));
            obj.Global.upper = obj.Global.lower+fix(1000/obj.Global.D)-1;
%             obj.Global.lower    =[1, 31, 61, 91, 121, 151, 181, 211];
%             obj.Global.upper     = [30, 60, 90, 120, 150, 180, 210, 240];
            obj.Global.encoding = 'real';
        end
    %% Calculate objective values
        function PopObj = CalObj(obj,X)
            M = obj.Global.M;
            PopObj = Cal(X);          
        end
    %% Calculate constraint violations
    %obj是一个对象，表示一个优化问题，obj.gloabl是自带的全局属性，obj.other，other可以自定义方法。
        function PopCon = CalCon(obj,X)
            PopObj = obj.CalObj(X);
            PopCon = 1 - PopObj(:,1) - PopObj(:,2) + abs(sin(10*pi*(PopObj(:,1)-PopObj(:,2)+1)));
        end
    %% Sample reference points on Pareto front 
        function P = PF(obj,N)
           load pf.mat;
           f(:,1) = flj(:,1);
           f(:,2) = flj(:,2);
           f(:,3) = flj(:,3);
           f(:,4) = flj(:,4);
           P = f
        end
    end  
 end

            